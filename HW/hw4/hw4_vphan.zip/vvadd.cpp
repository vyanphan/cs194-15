#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <string>
#include "clhelp.h"

int main(int argc, char *argv[]) {
    // Provide names of the OpenCL kernels and cl file that they're kept in
    std::string vvadd_kernel_str;
    std::string vvadd_name_str = std::string("vvadd");
    std::string vvadd_kernel_file = std::string("vvadd.cl");

    cl_vars_t cv;                                       // Declare our variable list
    cl_kernel vvadd;                                    // Declare our kernel (our instruction is vector addition)
    readFile(vvadd_kernel_file, vvadd_kernel_str);      // Read OpenCL file into STL string
    initialize_ocl(cv);                                 // Initialize the OpenCL runtime. Source in clhelp.cpp
    compile_ocl_program(vvadd, cv, vvadd_kernel_str.c_str(), vvadd_name_str.c_str()); // Compile all OpenCL kernels
    
    float *h_A, *h_B, *h_Y;                             // Arrays on the host (CPU) 
    cl_mem g_A, g_B, g_Y;                               // Arrays on the device (GPU)
    int n = (1<<20);                                    // Allocate arrays on the host (size global workspace to this later)
    h_A = new float[n];                                 // Input A
    h_B = new float[n];                                 // Input B
    h_Y = new float[n];                                 // Result destination Y
    bzero(h_Y, sizeof(float)*n);                        // Zero out Y, our destination array
    for(int i = 0; i < n; i++) {                        // Fill A and B, our input arrays, with random data
        h_A[i] = (float)drand48();
        h_B[i] = (float)drand48();
    }

    cl_int err = CL_SUCCESS;                            // Allocate memory for arrays on the GPU
    g_Y = clCreateBuffer(cv.context, CL_MEM_READ_WRITE, sizeof(float)*n, NULL, &err);
    CHK_ERR(err);
    g_A = clCreateBuffer(cv.context, CL_MEM_READ_WRITE, sizeof(float)*n, NULL, &err);
    CHK_ERR(err);
    g_B = clCreateBuffer(cv.context, CL_MEM_READ_WRITE, sizeof(float)*n, NULL, &err);
    CHK_ERR(err);
  
    // Write commands to a buffer object from host memory; copy data from host CPU to GPU
    err = clEnqueueWriteBuffer(cv.commands, g_Y, true, 0, sizeof(float)*n, h_Y, 0, NULL, NULL);
    CHK_ERR(err);
    err = clEnqueueWriteBuffer(cv.commands, g_A, true, 0, sizeof(float)*n, h_A, 0, NULL, NULL);
    CHK_ERR(err);
    err = clEnqueueWriteBuffer(cv.commands, g_B, true, 0, sizeof(float)*n, h_B, 0, NULL, NULL);
    CHK_ERR(err);
     
    // Define global workgroup to size of array and local workgroup to whatever we want
    size_t global_work_size[1] = {n};
    size_t local_work_size[1] = {1};
      
    // Set kernel arguments (dest Y, input A, input B, size n)
    err = clSetKernelArg(vvadd, 0, sizeof(cl_mem), &g_Y);
    CHK_ERR(err);
    err = clSetKernelArg(vvadd, 1, sizeof(cl_mem), &g_A);
    CHK_ERR(err);
    err = clSetKernelArg(vvadd, 2, sizeof(cl_mem), &g_B);
    CHK_ERR(err);
    err = clSetKernelArg(vvadd, 3, sizeof(int), &n);
    CHK_ERR(err);   

    // Divvy up our incr job into local workspaces; put kernel vvadd on the queue to execute on GPU
    err = clEnqueueNDRangeKernel(cv.commands,
                                vvadd,                      // our kernel, vector addition (what we want to do)
                                1,                          // work_dim, #dims work group uses to execute kernel
                                NULL,                       // global_work_offset
                                global_work_size,           // global_work_size, array size work_dim holding dims of kernel
                                local_work_size,            // local_work_size, array size work_dim holding dims of work group
                                0,                          // num_events_in_wait_list
                                NULL,                       // event_wait_list
                                NULL);
    CHK_ERR(err);

    // Read result of GPU on host CPU (this is where we execute all the actual adding stuff)
    err = clEnqueueReadBuffer(cv.commands, g_Y, true, 0, sizeof(float)*n, h_Y, 0, NULL, NULL);
    CHK_ERR(err);
    err = clEnqueueReadBuffer(cv.commands, g_A, true, 0, sizeof(float)*n, h_A, 0, NULL, NULL);
    CHK_ERR(err);
    err = clEnqueueReadBuffer(cv.commands, g_B, true, 0, sizeof(float)*n, h_B, 0, NULL, NULL);
    CHK_ERR(err);

    // Checking our OpenCL-added array against manual addition
    for(int i = 0; i < n; i++) {
        float d = h_A[i] + h_B[i];
        if(h_Y[i] != d) {
            printf("Error at %d\n. Output: %f  Expected: %f\n", i, h_Y[i], d);
            break;
    	}
    }

    // Clear memory and free arrays; shut down OpenCL runtime
    uninitialize_ocl(cv);
    delete [] h_A;
    delete [] h_B;
    delete [] h_Y;
    clReleaseMemObject(g_A);
    clReleaseMemObject(g_B);
    clReleaseMemObject(g_Y);
    return 0;
}
