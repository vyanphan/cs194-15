#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <string>
#include "clhelp.h"

int main(int argc, char *argv[]) {
    // Provide names of the OpenCL kernels and cl file that they're kept in 
    std::string incr_kernel_str;
    std::string incr_name_str = std::string("incr");
    std::string incr_kernel_file = std::string("incr.cl");

    cl_vars_t cv;                                   // Declare our variable list
    cl_kernel incr;                                 // Declare our kernel (our instruction is the incr function)
    readFile(incr_kernel_file, incr_kernel_str);    // Read OpenCL file into STL string
    initialize_ocl(cv);                             // Initialize the OpenCL runtime. Source in clhelp.cpp
    compile_ocl_program(incr, cv, incr_kernel_str.c_str(), incr_name_str.c_str());  // Compile all OpenCL kernels
    
    float *h_Y, *h_YY;                              // Arrays on the host (CPU)
    cl_mem g_Y;                                     // Arrays on the device (GPU)
    int n = (1<<20);                                // Allocate arrays on the host (size global workspace to this later)
    h_Y = new float[n];                             // Initialize random identical float arrays h_Y and h_YY of size n
    h_YY = new float[n];                            // h_YY is our reference array; h_Y is the one we'll increment 
    for(int i = 0; i < n; i++) {                    // Fill out h_Y and h_YY with the same random data
        h_YY[i] = h_Y[i] = (float)drand48();
    }

    cl_int err = CL_SUCCESS;                        // Allocate memory for arrays on the GPU (with error checking)
    g_Y = clCreateBuffer(cv.context,CL_MEM_READ_WRITE, sizeof(float)*n, NULL, &err);
    CHK_ERR(err);

    // Write commands to a buffer object from host memory; copy data from host CPU to GPU
    err = clEnqueueWriteBuffer(cv.commands, g_Y, true, 0, sizeof(float)*n, h_Y, 0, NULL, NULL);
    CHK_ERR(err);

    // Our global workspace should be the total size of our array; we picked 128 for the size of our local chunks
    size_t global_work_size[1] = {n};
    size_t local_work_size[1] = {128};
    
    // Set kernel arguments (array Y, size n)
    err = clSetKernelArg(incr, 0, sizeof(cl_mem), &g_Y);
    CHK_ERR(err);
    err = clSetKernelArg(incr, 1, sizeof(int), &n);
    CHK_ERR(err);
   
    // Divvy up our incr job into local workspaces; put kernel incr on the queue to execute on GPU
    err = clEnqueueNDRangeKernel(cv.commands,
                                incr,                       // our kernel, vector increment (what we want to do)
                                1,                          // work_dim, #dims work group uses to execute kernel
                                NULL,                       // global_work_offset
                                global_work_size,           // global_work_size, array size work_dim holding dims of kernel
                                local_work_size,            // local_work_size, array size work_dim holding dims of work group
                                0,                          // num_events_in_wait_list
                                NULL,                       // event_wait_list
                                NULL);
    CHK_ERR(err);

    // Read result of GPU on host CPU (this is where we execute all the actual incr stuff)
    err = clEnqueueReadBuffer(cv.commands, g_Y, true, 0, sizeof(float)*n, h_Y, 0, NULL, NULL);
    CHK_ERR(err);

    // checking our OpenCL-incremented array (h_Y) against our manually incremented array (h_YY)
    bool er = false;
    for(int i = 0; i < n; i++) {
        float d = (h_YY[i] + 1.0f);
        if(h_Y[i] != d) {
  	        printf("error at %d\n", i);
  	        er = true;
            break;
        }
    }
    if(!er) {
        printf("CPU and GPU results match\n");
    }

    // Clear memory and free arrays; shut down OpenCL runtime
    uninitialize_ocl(cv);
    delete [] h_Y;
    delete [] h_YY;
    clReleaseMemObject(g_Y);
    return 0;
}
