#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <cassert>
#include <cmath>

#include "clhelp.h"

void sqr_sgemm(float *Y, float *A, float *B, int n);

int main(int argc, char *argv[]) {
    // Provide names of the OpenCL kernels and cl file that they're kept in
    std::string matmul_kernel_str;
    std::string matmul_name_str = std::string("matmul");
    std::string matmul_kernel_file = std::string("matmul.cl");

    cl_vars_t cv;                                           // Declare our variable list
    cl_kernel matmul;                                       // Declare our kernel (matrix multiply)
    readFile(matmul_kernel_file, matmul_kernel_str);        // Read OpenCL file into STL string
    initialize_ocl(cv);                                     // Initialize the OpenCL runtime source in clhelp.cpp
    compile_ocl_program(matmul, cv, matmul_kernel_str.c_str(), matmul_name_str.c_str()); // Compile all OpenCl kernels
  
    float *h_A, *h_B, *h_Y, *h_YY;                          // Matrices on the host (CPU) 
    cl_mem g_A, g_B, g_Y;                                   // Matrices on the device (GPU)
    int n = (1<<10);                                        // Allocate matrices on host (size global workspace to this later)
    h_A = new float[n*n];                                   // Input A
    assert(h_A);
    h_B = new float[n*n];                                   // Input B
    assert(h_B);
    h_Y = new float[n*n];                                   // Result destination Y
    assert(h_Y);
    h_YY = new float[n*n];                                  // Reference result YY
    assert(h_YY);
    bzero(h_Y, sizeof(float)*n*n);                          // Zero out Y, our destination matrix
    bzero(h_YY, sizeof(float)*n*n);                         // Zero out YY, our reference matrix
    for(int i = 0; i < (n*n); i++) {                        // Fill A and B, our input matrices, with random data
        h_A[i] = (float)drand48();
        h_B[i] = (float)drand48();
    }

    cl_int err = CL_SUCCESS;                                // Allocate memory for matrices on the GPU
    g_Y = clCreateBuffer(cv.context,CL_MEM_READ_WRITE, sizeof(float)*n*n, NULL, &err);
    CHK_ERR(err);
    g_A = clCreateBuffer(cv.context,CL_MEM_READ_WRITE, sizeof(float)*n*n, NULL, &err);
    CHK_ERR(err);
    g_B = clCreateBuffer(cv.context,CL_MEM_READ_WRITE, sizeof(float)*n*n, NULL, &err);
    CHK_ERR(err);
  
    // Write commands to a buffer object from host memory; copy data from host CPU to GPU
    err = clEnqueueWriteBuffer(cv.commands, g_Y, true, 0, sizeof(float)*n*n, h_Y, 0, NULL, NULL);
    CHK_ERR(err);
    err = clEnqueueWriteBuffer(cv.commands, g_A, true, 0, sizeof(float)*n*n, h_A, 0, NULL, NULL);
    CHK_ERR(err);
    err = clEnqueueWriteBuffer(cv.commands, g_B, true, 0, sizeof(float)*n*n, h_B, 0, NULL, NULL);
    CHK_ERR(err);

    // Define global workgroup to size of matrix and local workgroup to whatever we want
    size_t global_work_size[2] = {n, n};
    size_t local_work_size[2] = {16, 16};
  
    // Set kernel arguments (dest Y, input A, input B, size n)
    err = clSetKernelArg(matmul, 0, sizeof(cl_mem), &g_Y);
    CHK_ERR(err);
    err = clSetKernelArg(matmul, 1, sizeof(cl_mem), &g_A);
    CHK_ERR(err);
    err = clSetKernelArg(matmul, 2, sizeof(cl_mem), &g_B);
    CHK_ERR(err);
    err = clSetKernelArg(matmul, 3, sizeof(int), &n);
    CHK_ERR(err);   

    // Divvy up our incr job into local workspaces; put kernel matmul on the queue to execute on GPU
    double t0 = timestamp();
    err = clEnqueueNDRangeKernel(cv.commands,
                                matmul,                     // our kernel, matrix multiply (what we want to do)
                                2,                          // work_dim, #dims work group uses to execute kernel
                                NULL,                       // global_work_offset
                                global_work_size,           // global_work_size, matrix size work_dim holding dims of kernel
                                local_work_size,            // local_work_size, matrix size work_dim holding dims of work group
                                0,                          // num_events_in_wait_list
                                NULL,                       // event_wait_list
                                NULL);
    CHK_ERR(err);
    err = clFinish(cv.commands);
    CHK_ERR(err);
    t0 = timestamp()-t0;


    // Read result of GPU on host CPU (this is where we execute all the actual incr stuff)
    err = clEnqueueReadBuffer(cv.commands, g_Y, true, 0, sizeof(float)*n*n, h_Y, 0, NULL, NULL);
    CHK_ERR(err);
    err = clEnqueueReadBuffer(cv.commands, g_A, true, 0, sizeof(float)*n*n, h_A, 0, NULL, NULL);
    CHK_ERR(err);
    err = clEnqueueReadBuffer(cv.commands, g_B, true, 0, sizeof(float)*n*n, h_B, 0, NULL, NULL);
    CHK_ERR(err);
    err = clFinish(cv.commands);
    CHK_ERR(err);

    double t1 = timestamp();
    sqr_sgemm(h_YY, h_A, h_B, n);
    t1 = timestamp()-t1;

    // Checking our OpenCL-multiplied matrix against manual multiplication
    for(int i = 0; i < (n*n); i++) {
        double d = h_YY[i] - h_Y[i];
        d *= d;
        if(d > 0.0001) {
            printf("Output: %f  Expected: %f\n", h_Y[i], h_YY[i]);
            break;
        }
    }
  
    // Clear memory and free matrices; shut down OpenCL runtime
    uninitialize_ocl(cv);
    delete [] h_A; 
    delete [] h_B; 
    delete [] h_Y;
    delete [] h_YY;
    clReleaseMemObject(g_A); 
    clReleaseMemObject(g_B); 
    clReleaseMemObject(g_Y);
  
    double gpu_flops_s = (2.0 * pow((double)n, 3.0)) / t0;
    printf("GPU: %g gflops/sec\n", gpu_flops_s / (1e9));

    double cpu_flops_s = (2.0 * pow((double)n, 3.0)) / t1;
    printf("CPU: %g gflops/sec\n", cpu_flops_s / (1e9));
    return 0;
}
